#!/usr/bin/env bash

zip -q -r template_bridge_ios.zip ./
mv template_bridge_ios.zip ../../tools-rsbind/src/ios/res/