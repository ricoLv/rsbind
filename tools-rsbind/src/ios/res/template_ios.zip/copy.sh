#!/usr/bin/env bash

zip -q -r template_ios.zip ./
mv template_ios.zip ../../tools-rsbind/src/ios/res/